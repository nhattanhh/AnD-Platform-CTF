#!/bin/bash

# Create SSH user from environment variables
SSH_USERNAME=${SSH_USERNAME:-ctf}
SSH_PASSWORD=${SSH_PASSWORD:-ctf123}

# Update ctf user password if provided
echo "ctf:${SSH_PASSWORD}" | chpasswd

# Create additional SSH user if specified and different from ctf
if [ "$SSH_USERNAME" != "ctf" ]; then
    if ! id "$SSH_USERNAME" &>/dev/null; then
        useradd -m -s /bin/bash "$SSH_USERNAME"
    fi
    echo "$SSH_USERNAME:$SSH_PASSWORD" | chpasswd
fi

# Start SSH service
service ssh start

# Start the vulnerable service
exec python3 /app/service.py
