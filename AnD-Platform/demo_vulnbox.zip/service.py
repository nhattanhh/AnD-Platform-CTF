#!/usr/bin/env python3
"""
Simple vulnerable service for CTF testing.
This service has an intentional vulnerability for demonstration purposes.

Flag locations (as per tick_worker.py):
- USER flag: /home/ctf/flag1.txt
- ROOT flag: /root/flag2.txt
"""

import socket
import threading


# Flag paths matching tick_worker.py
USER_FLAG_PATH = "/home/ctf/flag1.txt"
ROOT_FLAG_PATH = "/root/flag2.txt"


def read_flag(flag_type="user"):
    """Read the current flag from file."""
    try:
        if flag_type == "root":
            path = ROOT_FLAG_PATH
        else:
            path = USER_FLAG_PATH
        
        with open(path, "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return f"FLAG{{placeholder_{flag_type}}}"
    except PermissionError:
        return "ERROR: Permission denied"


def handle_client(client_socket):
    """Handle incoming client connections."""
    try:
        client_socket.send(b"Welcome to the Test Service!\n")
        client_socket.send(b"Commands: PING, STATUS, GETFLAG, GETROOTFLAG, QUIT\n> ")
        
        while True:
            data = client_socket.recv(1024).decode().strip()
            
            if not data:
                break
            
            command = data.upper()
            
            if command == "PING":
                client_socket.send(b"PONG\n> ")
            elif command == "STATUS":
                client_socket.send(b"SERVICE: OK\n> ")
            elif command == "GETFLAG":
                # Intentional vulnerability: user flag leakage
                flag = read_flag("user")
                client_socket.send(f"FLAG: {flag}\n> ".encode())
            elif command == "GETROOTFLAG":
                # Intentional vulnerability: root flag leakage (harder to exploit normally)
                flag = read_flag("root")
                client_socket.send(f"FLAG: {flag}\n> ".encode())
            elif command == "QUIT":
                client_socket.send(b"Goodbye!\n")
                break
            else:
                client_socket.send(b"Unknown command\n> ")
                
    except Exception as e:
        print(f"Error handling client: {e}")
    finally:
        client_socket.close()


def main():
    """Start the vulnerable service."""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", 5000))
    server.listen(5)
    
    print("Test service running on port 5000...")
    
    while True:
        client, addr = server.accept()
        print(f"Connection from {addr}")
        client_thread = threading.Thread(target=handle_client, args=(client,))
        client_thread.start()


if __name__ == "__main__":
    main()
